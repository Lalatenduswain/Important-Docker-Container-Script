This app is pre-setup with an admin account. The initial credentials are:

**Username**: administrator<br/>
**Password**: administrator<br/>

Please change the admin password and email immediately.

