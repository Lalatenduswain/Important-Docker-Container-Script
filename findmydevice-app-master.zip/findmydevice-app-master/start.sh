#!/bin/bash

set -eu

mkdir -p /app/data

if [[ ! -f /app/data/config.yml ]]; then
  cp /app/pkg/config.yml /app/data/config.yml
fi

yq eval -i ".PortInsecure=8080" /app/data/config.yml

chown -R cloudron:cloudron /app/data

echo "==> Starting FMD"
exec gosu cloudron:cloudron /app/code/findmydeviceserver serve --db-dir=/app/data --config=/app/data/config.yml --web-dir=/app/code/web
