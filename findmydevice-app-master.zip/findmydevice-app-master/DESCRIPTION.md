## About

This is the official server for FindMyDevice (FMD) written in Go.
The FMD app can register an account on FMD Server.
The app can then upload its location at regular intervals.
You can also push commands to the FMD app on your device from FMD Server,
e.g. to make your device ring.

The FMD app for android can be found here https://gitlab.com/Nulide/findmydevice great!