Repo of the Cloudron package for [FindMyDevice](https://gitlab.com/Nulide/findmydeviceserver)
