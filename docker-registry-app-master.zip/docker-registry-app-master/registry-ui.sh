# Add custom registry environment variables here. See https://joxit.dev/docker-registry-ui/#available-options

# export REGISTRY_TITLE="Cloudron Registry"

