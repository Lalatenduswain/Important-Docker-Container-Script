The first account is automatically the administrator.

